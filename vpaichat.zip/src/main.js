/**
 * VPAICore – src/main.js
 * Rol: Electron main: window + IPC doorverwijzers
 * Koppelingen: ipc/registerIpc, ui/window
 * Belangrijk: Geen business logic; alleen registreren + window
 *
 * Conventies:
 * - Houd main.js dun (alleen IPC doorverwijzers).
 * - Startobject is SSOT-regiekamer; pad hard uit init/ini.cfg of config/ini.cfg.
 * - AI seed: compacte index + startobject in system prompt (renderer of service).
 */

// src/main.js
const { app, BrowserWindow } = require("electron");
const { registerIpc } = require("./ipc/registerIpc");
const { readStartObject } = require("./core/startObject");
const { createMainWindow } = require("./ui/window");
const { checkIniConfig, ensureDataDirectory } = require("./core/appInit");
const { loadApiKey } = require("./infra/apiKeyStore");
const { createKeyWindow } = require("./ui/keyWindow");

const config = checkIniConfig();
const dataDir = ensureDataDirectory(config);
console.log("[Main] Data-dir:", dataDir);

let mainWindow = null;

app.whenReady().then(() => {
  mainWindow = createMainWindow();

  // registreer ALLE ipc-handlers (startobject + chat)
  registerIpc();


 // Als er (nog) geen key is: wizard tonen
try {
    const key = loadApiKey();
    if (!key) {
      createKeyWindow();
    }
  } catch (e) {
    console.warn("[Main] API key load fout:", e?.message);
    createKeyWindow();
  }


  mainWindow.webContents.on("did-finish-load", () => {
    try {
      const { obj } = readStartObject();
      const titel = obj?.config?.titel || obj?.titel || "vpAIChat";
      const omschrijving = obj?.config?.omschrijving || obj?.omschrijving || "AI chatomgeving";
      mainWindow.webContents.send("core:setTitle", titel);
      mainWindow.webContents.send("core:setDescription", omschrijving);
    } catch (e) {
      console.error("[did-finish-load] Startobject fout:", e.message);
    }
  });

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      mainWindow = createMainWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
