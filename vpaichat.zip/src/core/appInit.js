// src/core/appInit.js

const path = require('path');
const fs = require('fs');
const ini = require('ini');
const configPath = path.join(__dirname, '../../config/ini.cfg');

 function checkIniConfig() {
   if (!fs.existsSync(configPath)) {
     throw new Error('ini.cfg niet gevonden. Start eerst de installatie.');
   }

  const config = ini.parse(fs.readFileSync(configPath, 'utf-8'));
  // Normaliseer paden en vul defaults volgens Blauwdruk
  const cfg = {
    paths: {
      data_dir: config?.paths?.data_dir ?? './data',
      startobject_file: config?.paths?.startobject_file ?? null,
    },
    security: config?.security ?? {},
  };
  // Maak absoluut relatief aan ini-locatie
  const iniDir = path.dirname(configPath);
  cfg.paths.data_dir = path.isAbsolute(cfg.paths.data_dir)
    ? cfg.paths.data_dir
    : path.resolve(iniDir, cfg.paths.data_dir);
  return cfg;
 }

 function ensureDataDirectory(config) {
  const dataDir = config.paths?.data_dir || './data';
   if (!fs.existsSync(dataDir)) {
     throw new Error(`Data map ontbreekt: ${dataDir}`);
   }
   return dataDir;
 }


module.exports = {
  checkIniConfig,
  ensureDataDirectory,
};
