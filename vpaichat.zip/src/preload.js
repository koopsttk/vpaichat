/**
 * VPAICore – src/preload.js
 * Rol: Preload bridge: expose API naar renderer
 * Koppelingen: ipcRenderer.invoke/on
 * Belangrijk: Geen business logic; alleen proxies
 *
 * Conventies:
 * - Houd main.js dun (alleen IPC doorverwijzers).
 * - Startobject is SSOT-regiekamer; pad hard uit init/ini.cfg of config/ini.cfg.
 * - AI seed: compacte index + startobject in system prompt (renderer of service).
 */

// preload.js
const { contextBridge, ipcRenderer } = require("electron");

const api = {
  // Core
  getStartObject: () => ipcRenderer.invoke("core:getStartObject"),
  getAppConfig:   () => ipcRenderer.invoke("core:getAppConfig"),

  updateField: (objectType, id, field, value) =>
    ipcRenderer.invoke("ssot:updateField", { objectType, id, field, value }),

  // Openen van objecten (bv. startobject, adresobject, etc.)
  openObject: (role, name) =>
    ipcRenderer.invoke("ssot:openObject", { role, name }),

  // Titel/omschrijving updates
  onSetTitle: (cb) =>
    ipcRenderer.on("core:setTitle", (_evt, data) => cb?.(data)),
  onSetDescription: (cb) =>
    ipcRenderer.on("core:setDescription", (_evt, data) => cb?.(data)),

  // AI chat
  aiChat: (messages, model = "gpt-4o-mini", system) =>
    ipcRenderer.invoke("ai:chat", { messages, model, system }),
  onAiChunk: (cb) =>
    ipcRenderer.on("ai:chunk", (_evt, data) => cb?.(data)),
};

const startobj = {
  read: () => ipcRenderer.invoke("startobj:read"),
  update: (json) => {
    if (!json || typeof json !== "object") {
      return Promise.resolve({ ok: false, error: "Lege of ongeldige JSON payload" });
    }
    if (json.rol !== "startobject") {
      return Promise.resolve({ ok: false, error: "Veld 'rol' moet 'startobject' zijn" });
    }
    return ipcRenderer.invoke("startobj:update", { json });
  },
  listBackups: () => ipcRenderer.invoke("startobj:listBackups"),
  restore: (which) => ipcRenderer.invoke("startobj:restore", which)
};

const ssot = {
  aiCreateObject: (payload) => {
    if (!payload || typeof payload !== "object") {
      return Promise.resolve({ ok: false, error: "Lege of ongeldige payload" });
    }
    if (!payload.role) {
      return Promise.resolve({ ok: false, error: "Veld 'role' ontbreekt" });
    }
    if (!payload.instruction) {
      return Promise.resolve({ ok: false, error: "Veld 'instruction' ontbreekt" });
    }
    return ipcRenderer.invoke("ssot:aiCreateObject", payload);
  }
};

const off = {
  channel: (name, handler) => {
    try { ipcRenderer.removeListener(name, handler); } catch {}
  }
};
getCompactIndex: () => ipcRenderer.invoke("index:get"),
contextBridge.exposeInMainWorld("api", api);
contextBridge.exposeInMainWorld("startobj", startobj);
contextBridge.exposeInMainWorld("ssot", ssot);
contextBridge.exposeInMainWorld("off", off);
